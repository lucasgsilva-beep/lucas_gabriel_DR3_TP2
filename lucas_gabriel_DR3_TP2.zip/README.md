# Lucas Gabriel — DR3 TP2

Implementações solicitadas para a atividade DR3 TP2, organizadas em cinco arquivos Python.

## Arquivos
- `p1q1.py`: FastAPI + GPT-2 para continuação de texto.
- `p1q2.py`: FastAPI + Helsinki-NLP/opus-mt-en-fr.
- `p2q1.py`: FastAPI + LangChain FakeListLLM.
- `p2q2.py`: FastAPI + LangChain + OpenAI (gpt-4o-mini por padrão).
- `p2q3.py`: FastAPI + LangChain + Helsinki-NLP/opus-mt-en-de.

## Instalação
Recomenda-se Python 3.10 ou 3.11 e ambiente virtual.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Os modelos Hugging Face são baixados na primeira execução e podem exigir vários minutos e espaço em disco. A primeira chamada também inclui o carregamento do modelo.

## Execução
Execute um arquivo por vez, na raiz do projeto:

```bash
uvicorn p1q1:app --reload
```

Troque `p1q1` por `p1q2`, `p2q1`, `p2q2` ou `p2q3`, conforme o exercício. Acesse `http://127.0.0.1:8000/docs`.

Para `p2q2.py`, configure `OPENAI_API_KEY` como variável de ambiente. Não coloque a chave no código nem a envie ao GitHub.

## Exemplos
GPT-2 — POST `/generate`:
```json
{"prompt":"Once upon a time","max_new_tokens":60}
```

Tradução — POST `/translate`:
```json
{"text":"Good morning. How are you?"}
```

Fake chatbot — POST `/chat`:
```json
{"text":"Olá"}
```

## Observações técnicas
- As rotas retornam JSON e usam modelos Pydantic para validar a entrada.
- O carregamento dos modelos é mantido em cache no processo para evitar recarregá-los a cada requisição.
- Os modelos locais usam CPU por padrão. Para produção, avalie GPU, workers, filas, limites de tamanho, timeouts e monitoramento.
- O protótipo FakeListLLM retorna respostas pré-programadas; não é um modelo generativo real.
- O endpoint de tradução local aplica limite de tokens e truncamento do pipeline; para textos extensos, implemente divisão em segmentos com preservação de parágrafos e recomposição.
- Não suba `.venv`, pesos de modelos, arquivos `.env` ou chaves para o GitHub.

## Publicação no GitHub
Crie um repositório público chamado `lucas_gabriel`, adicione estes arquivos e copie a URL real do repositório para o PDF de entrega. O PDF contém um campo para inserir essa URL; ela não foi inventada nem publicada automaticamente.
