"""
Parte 2 - Questão 1
Chatbot de demonstração com LangChain FakeListLLM.

Instalação:
    pip install -r requirements.txt
Execução:
    uvicorn p2q1:app --reload

POST /chat
JSON: {"text": "Olá"}
"""
from fastapi import FastAPI
from pydantic import BaseModel, Field
from langchain_community.llms.fake import FakeListLLM
from langchain_core.prompts import PromptTemplate

app = FastAPI(title="LangChain Fake LLM Chatbot", version="1.0.0")

class ChatRequest(BaseModel):
    text: str = Field(min_length=1, max_length=2000)

class ChatResponse(BaseModel):
    response: str

# Respostas determinísticas: úteis para validar a API sem custo de inferência.
fake_llm = FakeListLLM(responses=[
    "Olá! Como posso ajudar?",
    "Este é um protótipo de chatbot com respostas simuladas.",
    "Não tenho uma resposta cadastrada para isso, mas posso encaminhar a solicitação.",
])
prompt = PromptTemplate.from_template("Mensagem recebida: {question}")
chain = prompt | fake_llm

@app.post("/chat", response_model=ChatResponse)
def chat(data: ChatRequest):
    answer = chain.invoke({"question": data.text})
    return {"response": answer}

@app.get("/")
def root():
    return {"message": "Chatbot de teste ativo. Use POST /chat."}
