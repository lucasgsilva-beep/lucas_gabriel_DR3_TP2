"""
Parte 1 - Questão 2
API FastAPI para tradução inglês -> francês com Helsinki-NLP/opus-mt-en-fr.

Execução:
    uvicorn p1q2:app --reload

POST /translate
JSON: {"text": "Good morning, how are you?"}
"""
from functools import lru_cache
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from transformers import pipeline

MODEL_NAME = "Helsinki-NLP/opus-mt-en-fr"
app = FastAPI(title="English to French Translation API", version="1.0.0")

class TranslationRequest(BaseModel):
    text: str = Field(min_length=1, max_length=10000)

class TranslationResponse(BaseModel):
    translated_text: str
    source_language: str = "en"
    target_language: str = "fr"

@lru_cache(maxsize=1)
def get_translator():
    return pipeline("translation", model=MODEL_NAME)

@app.post("/translate", response_model=TranslationResponse)
def translate(data: TranslationRequest):
    try:
        translated = get_translator()(data.text, truncation=True, max_length=512)
        return {
            "translated_text": translated[0]["translation_text"],
            "source_language": "en",
            "target_language": "fr",
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Falha na tradução: {exc}") from exc

@app.get("/")
def root():
    return {"message": "Envie um POST para /translate."}
