"""
Parte 2 - Questão 2
API de tradução inglês -> francês com LangChain + OpenAI.

Configure OPENAI_API_KEY no ambiente antes de executar.
Opcional: defina OPENAI_MODEL (padrão: gpt-4o-mini).

Windows PowerShell:
    $env:OPENAI_API_KEY="sua-chave"
    uvicorn p2q2:app --reload

POST /translate
JSON: {"text": "The weather is beautiful today."}
"""
import os
from functools import lru_cache
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

app = FastAPI(title="LangChain OpenAI Translation API", version="1.0.0")

class TranslationRequest(BaseModel):
    text: str = Field(min_length=1, max_length=12000)

class TranslationResponse(BaseModel):
    translated_text: str
    source_language: str = "en"
    target_language: str = "fr"

@lru_cache(maxsize=1)
def get_chain():
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("Defina a variável de ambiente OPENAI_API_KEY.")
    model = ChatOpenAI(
        model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        temperature=0,
        timeout=45,
        max_retries=2,
    )
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a professional translator. Translate the user's text from English to French. Preserve meaning, tone, names, and formatting. Return only the French translation."),
        ("human", "{text}"),
    ])
    return prompt | model

@app.post("/translate", response_model=TranslationResponse)
def translate(data: TranslationRequest):
    try:
        result = get_chain().invoke({"text": data.text})
        return {"translated_text": result.content}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Falha no serviço de tradução: {exc}") from exc

@app.get("/")
def root():
    return {"message": "Envie um POST para /translate."}
