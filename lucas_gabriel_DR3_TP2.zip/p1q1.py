"""
Parte 1 - Questão 1
API FastAPI para continuação de texto com GPT-2 (Hugging Face).

Execução:
    pip install -r requirements.txt
    uvicorn p1q1:app --reload

POST /generate
JSON: {"prompt": "Era uma vez"}
"""
from functools import lru_cache
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from transformers import pipeline

app = FastAPI(title="GPT-2 Text Generation API", version="1.0.0")

class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=2000)
    max_new_tokens: int = Field(default=80, ge=1, le=200)

class GenerateResponse(BaseModel):
    generated_text: str

@lru_cache(maxsize=1)
def get_generator():
    # Na primeira execução, os pesos do modelo são baixados do Hugging Face.
    return pipeline("text-generation", model="gpt2")

@app.post("/generate", response_model=GenerateResponse)
def generate_text(data: GenerateRequest):
    try:
        result = get_generator()(
            data.prompt,
            max_new_tokens=data.max_new_tokens,
            do_sample=True,
            temperature=0.8,
            pad_token_id=50256,
            num_return_sequences=1,
        )
        return {"generated_text": result[0]["generated_text"]}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Falha na geração: {exc}") from exc

@app.get("/")
def root():
    return {"message": "Envie um POST para /generate."}
