"""
Parte 2 - Questão 3
API inglês -> alemão com LangChain e modelo Hugging Face local.

O modelo é baixado na primeira execução e executado localmente.
Execução:
    uvicorn p2q3:app --reload

POST /translate
JSON: {"text": "Good morning, welcome to Berlin."}
"""
from functools import lru_cache
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from transformers import pipeline
from langchain_community.llms import HuggingFacePipeline
from langchain_core.prompts import PromptTemplate

MODEL_NAME = "Helsinki-NLP/opus-mt-en-de"
app = FastAPI(title="LangChain Hugging Face EN-DE API", version="1.0.0")

class TranslationRequest(BaseModel):
    text: str = Field(min_length=1, max_length=10000)

class TranslationResponse(BaseModel):
    translated_text: str
    source_language: str = "en"
    target_language: str = "de"

@lru_cache(maxsize=1)
def get_chain():
    hf_pipeline = pipeline(
        "translation",
        model=MODEL_NAME,
        tokenizer=MODEL_NAME,
        device=-1,  # CPU; use device=0 se houver GPU CUDA configurada.
    )
    llm = HuggingFacePipeline(pipeline=hf_pipeline)
    prompt = PromptTemplate.from_template(
        "Translate the following English text into German. Return only the translation:\n{text}"
    )
    return prompt | llm

@app.post("/translate", response_model=TranslationResponse)
def translate(data: TranslationRequest):
    try:
        result = get_chain().invoke({"text": data.text})
        return {"translated_text": result.strip()}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Falha na tradução: {exc}") from exc

@app.get("/")
def root():
    return {"message": "Envie um POST para /translate."}
