from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from routes import InvalidItemIdException, router

app = FastAPI(
    title="FastAPI - Exercícios DR3 TP1",
    description="API desenvolvida para os 12 exercícios de FastAPI.",
    version="1.0.0",
)


@app.exception_handler(InvalidItemIdException)
async def invalid_item_id_handler(
    request: Request, exc: InvalidItemIdException
):
    return JSONResponse(
        status_code=400,
        content={"detail": str(exc)},
    )


app.include_router(router)


@app.get("/", tags=["Início"])
async def root():
    return {"message": "Hello, FastAPI!"}
