from datetime import date
from fastapi import APIRouter, HTTPException, status

from models import (
    BirthdayRequest,
    BirthdayResponse,
    CreateUserRequest,
    CreateUserResponse,
    UserResponse,
)

router = APIRouter()

# Armazenamento em memória apenas para fins didáticos.
USERS = {"john": {"username": "john", "age": 30}}
ITEMS = {
    1: {"item_id": 1, "name": "Notebook"},
    2: {"item_id": 2, "name": "Teclado"},
}


class InvalidItemIdException(Exception):
    """Exceção personalizada para identificadores de item inválidos."""


@router.get("/status", tags=["Geral"])
async def status_check():
    return {"status": "ok", "message": "Servidor funcionando!"}


@router.get(
    "/user/{username}",
    response_model=UserResponse,
    tags=["Usuários"],
)
async def get_user(username: str):
    if username not in USERS:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Usuário '{username}' não encontrado.",
        )

    return {
        "username": username,
        "message": f"Welcome, {username}!",
    }


@router.post(
    "/create-user",
    response_model=CreateUserResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Usuários"],
)
async def create_user(user: CreateUserRequest):
    if user.username in USERS:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"O usuário '{user.username}' já existe.",
        )

    USERS[user.username] = {
        "username": user.username,
        "age": user.age,
    }
    return {
        "username": user.username,
        "age": user.age,
        "message": "Usuário criado com sucesso.",
    }


def validate_item_id(item_id: str) -> int:
    """Valida o ID e converte para inteiro; inválidos geram erro 400."""
    if not item_id.isdigit() or int(item_id) <= 0:
        raise InvalidItemIdException(
            "item_id inválido: informe um número inteiro positivo."
        )
    return int(item_id)


@router.get("/item/{item_id}", tags=["Itens"])
async def get_item(item_id: str):
    validated_id = validate_item_id(item_id)
    item = ITEMS.get(validated_id)

    if item is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Item {validated_id} não encontrado.",
        )
    return item


@router.delete("/item/{item_id}", tags=["Itens"])
async def delete_item(item_id: str):
    validated_id = validate_item_id(item_id)

    if validated_id not in ITEMS:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Item {validated_id} não encontrado.",
        )

    del ITEMS[validated_id]
    return {
        "message": f"Item {validated_id} removido com sucesso."
    }


def next_birthday_days(birth_date: date, today: date | None = None) -> int:
    """Calcula os dias até o próximo aniversário, inclusive anos bissextos."""
    today = today or date.today()
    year = today.year

    try:
        next_birthday = date(year, birth_date.month, birth_date.day)
    except ValueError:
        # Para quem nasceu em 29/02, considera 28/02 em anos não bissextos.
        next_birthday = date(year, 2, 28)

    if next_birthday < today:
        year += 1
        try:
            next_birthday = date(year, birth_date.month, birth_date.day)
        except ValueError:
            next_birthday = date(year, 2, 28)

    return (next_birthday - today).days


@router.post(
    "/birthday",
    response_model=BirthdayResponse,
    tags=["Aniversário"],
)
async def birthday(data: BirthdayRequest):
    days = next_birthday_days(data.birth_date)
    if days == 0:
        message = f"Feliz aniversário, {data.name}!"
    else:
        message = (
            f"Olá, {data.name}! Faltam {days} dia(s) para o seu próximo aniversário."
        )

    return {
        "name": data.name,
        "birth_date": data.birth_date,
        "days_until_birthday": days,
        "message": message,
    }
