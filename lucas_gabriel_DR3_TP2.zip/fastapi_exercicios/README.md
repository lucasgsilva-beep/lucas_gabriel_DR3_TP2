# FastAPI - Exercícios DR3 TP1

Projeto único que reúne os 12 exercícios propostos.

## Requisitos
- Python 3.10 ou superior
- pip

## Criar e ativar o ambiente virtual

Windows (PowerShell):
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Windows (Prompt de Comando):
```bat
py -m venv .venv
.venv\Scripts\activate
```

Linux/macOS:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

## Instalar dependências e executar

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn main:app --reload
```

Acesse:
- Aplicação: http://127.0.0.1:8000/
- Swagger UI: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc

## Rotas

| Método | Rota | Função |
|---|---|---|
| GET | `/` | Hello, FastAPI! |
| GET | `/status` | Estado do servidor |
| GET | `/user/{username}` | Busca usuário existente |
| POST | `/create-user` | Cria usuário com username e age |
| GET | `/item/{item_id}` | Consulta item |
| DELETE | `/item/{item_id}` | Remove item |
| POST | `/birthday` | Calcula dias até o próximo aniversário |

## Exemplos para testar

POST `/create-user`:
```json
{
  "username": "maria",
  "age": 25
}
```

GET `/user/maria`:
```json
{
  "username": "maria",
  "message": "Welcome, maria!"
}
```

POST `/birthday`:
```json
{
  "name": "Maria",
  "birth_date": "2000-12-15"
}
```

Os usuários e itens são armazenados em memória: os dados são reiniciados quando o servidor é reiniciado. O usuário `john` e os itens `1` e `2` são exemplos iniciais.

## Observações
- A validação de `username`, `age` e `birth_date` é feita com Pydantic.
- `age` deve ser um inteiro positivo; entradas inválidas recebem HTTP 422 automaticamente.
- `item_id` inválido recebe HTTP 400 por meio de uma exceção personalizada.
- Usuários ou itens inexistentes recebem HTTP 404.
- O Swagger UI é gerado automaticamente pelo FastAPI.
- Não inclua a pasta `.venv` no arquivo de entrega.
