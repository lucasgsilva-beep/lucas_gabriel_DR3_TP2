from datetime import date
from pydantic import BaseModel, Field, field_validator


class UserResponse(BaseModel):
    username: str
    message: str


class CreateUserRequest(BaseModel):
    username: str = Field(min_length=1, max_length=50)
    age: int = Field(gt=0)

    @field_validator("username")
    @classmethod
    def username_must_not_be_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("O nome de usuário não pode ficar vazio.")
        return value


class CreateUserResponse(BaseModel):
    username: str
    age: int
    message: str


class BirthdayRequest(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    birth_date: date

    @field_validator("name")
    @classmethod
    def name_must_not_be_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("O nome não pode ficar vazio.")
        return value


class BirthdayResponse(BaseModel):
    name: str
    birth_date: date
    days_until_birthday: int
    message: str
